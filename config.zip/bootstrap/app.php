<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
        api: __DIR__ . '/../routes/api.php',
        commands: __DIR__ . '/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        // AJOUTE CETTE LIGNE ICI
        $middleware->alias([
            'commercial' => \App\Http\Middleware\CommercialMiddleware::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        // rien ici pour l’instant
    })->create();
