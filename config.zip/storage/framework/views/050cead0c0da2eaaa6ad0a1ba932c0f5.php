
<?php $__env->startSection('title', 'Nouvelle facture'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-4">
        <h1 class="h4 mb-3"><i class="bi bi-plus-circle me-2"></i>Nouvelle facture</h1>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <div class="fw-semibold mb-1">Corrige les erreurs suivantes :</div>
                <ul class="mb-0"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></ul>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('invoices.store')); ?>" method="POST" id="invoice-form">
                    <?php echo csrf_field(); ?>

                    <div class="row g-3 mb-2">
                        <div class="col-md-4">
                            <label class="form-label">Client</label>
                            <select name="customer_id" class="form-select <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                required>
                                <option value="">— Sélectionner —</option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php if(old('customer_id') == $id): echo 'selected'; endif; ?>><?php echo e($name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </select>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">Date</label>
                            <input type="date" name="invoiced_at" value="<?php echo e(old('invoiced_at', now()->format('Y-m-d'))); ?>"
                                class="form-control <?php $__errorArgs = ['invoiced_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['invoiced_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <div class="col-md-5">
                            <label class="form-label">Référence</label>
                            <input type="text" name="reference" value="<?php echo e(old('reference')); ?>"
                                class="form-control <?php $__errorArgs = ['reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ex: INV-2025-001"
                                required>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>

                    <hr>

                    
                    <div class="table-responsive">
                        <table class="table align-middle" id="lines-table">
                            <thead class="table-light">
                                <tr>
                                    <th style="width:38%">Produit</th>
                                    <th style="width:12%">Qté</th>
                                    <th style="width:20%">PU (€)</th>
                                    <th style="width:20%">Total ligne (€)</th>
                                    <th class="text-end" style="width:10%">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="lines-body">
                                
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="5">
                                        <button type="button" class="btn btn-outline-primary btn-sm" id="add-line">
                                            <i class="bi bi-plus-circle me-1"></i>Ajouter une ligne
                                        </button>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    <div class="d-flex justify-content-end mt-2">
                        <div class="text-end">
                            <div class="text-muted">Total facture</div>
                            <div class="h4 mb-0"><span id="invoice-total">0,00</span> €</div>
                            <input type="hidden" name="total" id="total-input" value="0">
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-3">
                        <a href="<?php echo e(route('invoices.index')); ?>" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left me-2"></i>Retour
                        </a>
                        <button class="btn btn-primary"><i class="bi bi-check2 me-2"></i>Créer la facture</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        (function () {
            const products = <?php echo json_encode($products->map(fn($p) => ['id' => $p->id, 'name' => $p->name, 'price' => $p->price])) ?>;
            const tbody = document.getElementById('lines-body');
            const addBtn = document.getElementById('add-line');
            const totalEl = document.getElementById('invoice-total');
            const totalInput = document.getElementById('total-input');

            function numberFr(x) { return (Math.round(x * 100) / 100).toFixed(2).replace('.', ','); }
            function parseVal(inp) { const v = parseFloat((inp.value || '0').toString().replace(',', '.')); return isNaN(v) ? 0 : v; }

            function recalc() {
                let total = 0;
                tbody.querySelectorAll('tr').forEach(tr => {
                    const qty = parseVal(tr.querySelector('.line-qty'));
                    const pu = parseVal(tr.querySelector('.line-unit'));
                    const lt = qty * pu;
                    tr.querySelector('.line-total').value = lt.toFixed(2);
                    tr.querySelector('.line-total-display').textContent = numberFr(lt);
                    total += lt;
                });
                totalEl.textContent = numberFr(total);
                totalInput.value = (Math.round(total * 100) / 100).toFixed(2);
            }

            function productOptionsHTML(selectedId = null) {
                return `<option value="">— Sélectionner —</option>` + products.map(p =>
                    `<option value="${p.id}" data-price="${p.price}" ${selectedId == p.id ? 'selected' : ''}>${p.name}</option>`
                ).join('');
            }

            function addLine(initial = { product_id: '', qty: 1, unit_price: '' }) {
                const idx = Date.now() + Math.floor(Math.random() * 1000);
                const tr = document.createElement('tr');
                tr.innerHTML = `
          <td>
            <select name="lines[${idx}][product_id]" class="form-select line-product" required>
              ${productOptionsHTML(initial.product_id)}
            </select>
          </td>
          <td>
            <input type="number" min="1" step="1" name="lines[${idx}][qty]" value="${initial.qty}" class="form-control line-qty">
          </td>
          <td>
            <input type="number" min="0" step="0.01" name="lines[${idx}][unit_price]" value="${initial.unit_price}" class="form-control line-unit">
          </td>
          <td>
            <div class="input-group">
              <input type="hidden" name="lines[${idx}][line_total]" class="line-total" value="0">
              <span class="form-control bg-light line-total-display text-end">0,00</span>
              <span class="input-group-text">€</span>
            </div>
          </td>
          <td class="text-end">
            <button type="button" class="btn btn-light btn-sm remove-line"><i class="bi bi-x-lg"></i></button>
          </td>
        `;
                tbody.appendChild(tr);

                const productSelect = tr.querySelector('.line-product');
                productSelect.addEventListener('change', () => {
                    const pu = productSelect.selectedOptions[0]?.dataset?.price ?? '';
                    const unitInput = tr.querySelector('.line-unit');
                    if (!unitInput.value) unitInput.value = pu || '';
                    recalc();
                });

                tr.addEventListener('input', e => {
                    if (e.target.classList.contains('line-qty') || e.target.classList.contains('line-unit')) recalc();
                });

                tr.querySelector('.remove-line').addEventListener('click', () => {
                    tr.remove(); recalc();
                });

                recalc();
            }

            addBtn.addEventListener('click', () => addLine());

            // Ajoute une première ligne par défaut
            addLine();
        })();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\rmoryson\Herd\infotools\resources\views/invoices/create.blade.php ENDPATH**/ ?>