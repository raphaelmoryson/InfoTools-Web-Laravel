<?php $__env->startSection('title', 'Rendez-vous'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-4">

    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap">
        <a href="<?php echo e(route('appointments.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle me-2"></i>Nouveau rendez-vous
        </a>
    </div>

    <div class="card mb-3">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('appointments.index')); ?>" class="row g-2">
                <div class="col-md-4">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-search"></i></span>
                        <input type="text" name="q" value="<?php echo e($q ?? ''); ?>" class="form-control" placeholder="Sujet ou client...">
                    </div>
                </div>
                <div class="col-md-3">
                    <input type="date" name="from" value="<?php echo e($dateFrom?->format('Y-m-d')); ?>" class="form-control" placeholder="Du">
                </div>
                <div class="col-md-3">
                    <input type="date" name="to" value="<?php echo e($dateTo?->format('Y-m-d')); ?>" class="form-control" placeholder="Au">
                </div>
                <div class="col-md-2 d-grid">
                    <button class="btn btn-outline-secondary"><i class="bi bi-sliders me-2"></i>Filtrer</button>
                </div>
            </form>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="card">
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Début</th>
                        <th>Fin</th>
                        <th>Client</th>
                        <th>Objet</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(\Carbon\Carbon::parse($a->start_at)->format('d/m/Y H:i')); ?></td>
                            <td><?php echo e($a->end_at ? \Carbon\Carbon::parse($a->end_at)->format('d/m/Y H:i') : '—'); ?></td>
                            <td><b><?php echo e($a->customer->first_name ?? '—'); ?> <?php echo e($a->customer->last_name); ?></b></td>
                            <td><?php echo e($a->subject); ?></td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('appointments.show', $a)); ?>" class="btn btn-light" title="Voir"><i class="bi bi-eye"></i></a>
                                    <a href="<?php echo e(route('appointments.edit', $a)); ?>" class="btn btn-light" title="Éditer"><i class="bi bi-pencil"></i></a>
                                    <form action="<?php echo e(route('appointments.destroy', $a)); ?>" method="POST" onsubmit="return confirm('Supprimer ce rendez-vous ?')">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-light" title="Supprimer"><i class="bi bi-trash"></i></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6" class="text-center text-muted py-4">Aucun rendez-vous.</td></tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appointments->hasPages()): ?>
            <div class="card-footer bg-white">
                <?php echo e($appointments->links()); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\rmoryson\Herd\infotools\resources\views/appointments/index.blade.php ENDPATH**/ ?>