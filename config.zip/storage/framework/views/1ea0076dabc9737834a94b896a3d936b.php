
<?php $__env->startSection('title', 'Détail du produit'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="h4"><i class="bi bi-box-seam me-2"></i><?php echo e($product->name); ?></h1>
        <div class="btn-group">
            <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-outline-secondary">
                <i class="bi bi-pencil me-2"></i>Éditer
            </a>
            <form action="<?php echo e(route('products.destroy', $product)); ?>" method="POST" onsubmit="return confirm('Supprimer ce produit ?')">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-outline-danger">
                    <i class="bi bi-trash me-2"></i>Supprimer
                </button>
            </form>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body row g-3">
            <div class="col-md-6">
                <div class="text-muted small">Nom</div>
                <div class="fw-semibold"><?php echo e($product->name); ?></div>
            </div>
            <div class="col-md-3">
                <div class="text-muted small">Prix</div>
                <div class="fw-semibold"><?php echo e(number_format($product->price, 2, ',', ' ')); ?> €</div>
            </div>
            <div class="col-md-3">
                <div class="text-muted small">Stock</div>
                <div class="fw-semibold"><?php echo e($product->stock); ?></div>
            </div>
            <div class="col-12">
                <div class="text-muted small">Description</div>
                <div><?php echo e($product->description ?: '—'); ?></div>
            </div>
        </div>
    </div>

    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-link mt-3">
        <i class="bi bi-arrow-left-short"></i>Retour à la liste
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\rmoryson\Herd\infotools\resources\views/products/show.blade.php ENDPATH**/ ?>