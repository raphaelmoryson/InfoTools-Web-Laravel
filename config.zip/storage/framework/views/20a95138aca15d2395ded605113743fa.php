
<?php $__env->startSection('title','Détail de la facture'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h4"><i class="bi bi-receipt me-2"></i>Facture <?php echo e($invoice->reference); ?></h1>
    <div class="btn-group">
      <a href="<?php echo e(route('invoices.edit', $invoice)); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-pencil me-2"></i>Éditer
      </a>
      <form action="<?php echo e(route('invoices.destroy', $invoice)); ?>" method="POST" onsubmit="return confirm('Supprimer cette facture ?')">
        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
        <button class="btn btn-outline-danger"><i class="bi bi-trash me-2"></i>Supprimer</button>
      </form>
    </div>
  </div>

  <div class="card shadow-sm border-0 mb-3">
    <div class="card-body row g-3">
      <div class="col-md-4">
        <div class="text-muted small">Client</div>
        <div class="fw-semibold"><?php echo e($invoice->customer->name ?? '—'); ?></div>
      </div>
      <div class="col-md-4">
        <div class="text-muted small">Date</div>
        <div class="fw-semibold"><?php echo e($invoice->invoiced_at?->format('d/m/Y')); ?></div>
      </div>
      <div class="col-md-4 text-md-end">
        <div class="text-muted small">Total</div>
        <div class="h4 mb-0"><?php echo e(number_format($invoice->total, 2, ',', ' ')); ?> €</div>
      </div>
      <div class="col-12">
        <div class="text-muted small">Référence</div>
        <div class="fw-semibold"><?php echo e($invoice->reference); ?></div>
      </div>
    </div>
  </div>

  <div class="card shadow-sm border-0">
    <div class="card-header bg-white fw-semibold">
      Lignes de la facture
    </div>
    <div class="table-responsive">
      <table class="table align-middle mb-0">
        <thead class="table-light">
          <tr>
            <th>Produit</th>
            <th class="text-end">Qté</th>
            <th class="text-end">PU (€)</th>
            <th class="text-end">Total ligne (€)</th>
          </tr>
        </thead>
        <tbody>
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $invoice->lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($line->product->name ?? '—'); ?></td>
              <td class="text-end"><?php echo e($line->qty); ?></td>
              <td class="text-end"><?php echo e(number_format($line->unit_price, 2, ',', ' ')); ?></td>
              <td class="text-end"><?php echo e(number_format($line->line_total, 2, ',', ' ')); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="4" class="text-center text-muted py-4">Aucune ligne.</td></tr>
          <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </tbody>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($invoice->lines->count()): ?>
        <tfoot>
          <tr>
            <th colspan="3" class="text-end">TOTAL</th>
            <th class="text-end"><?php echo e(number_format($invoice->total, 2, ',', ' ')); ?> €</th>
          </tr>
        </tfoot>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
      </table>
    </div>
  </div>

  <a href="<?php echo e(route('invoices.index')); ?>" class="btn btn-link mt-3">
    <i class="bi bi-arrow-left-short"></i>Retour à la liste
  </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\rmoryson\Herd\infotools\resources\views/invoices/show.blade.php ENDPATH**/ ?>