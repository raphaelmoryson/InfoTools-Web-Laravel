
<?php $__env->startSection('title', 'Clients'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-3">

    
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap">
        <h1 class="h3 mb-0">
            <i class="bi bi-people me-2"></i>Clients
        </h1>
        <a href="#" class="btn btn-primary">
            <i class="bi bi-person-plus me-2"></i>Ajouter un client
        </a>
    </div>

    
    <div class="card mb-3">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('customer.index')); ?>" class="row g-2 align-items-center">
                <div class="col-md-8">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-search"></i></span>
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control" placeholder="Rechercher un client, une société, un email...">
                    </div>
                </div>
                <div class="col-md-4 text-end">
                    <button type="submit" class="btn btn-outline-secondary w-100 w-md-auto">
                        Rechercher
                    </button>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table align-middle mb-0 table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Nom</th>
                            <th>Email</th>
                            <th>Téléphone</th>
                            <th>Société</th>
                            <th>Statut</th>
                            <th>Commercial</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($customer->id); ?></td>
                                <td><?php echo e($customer->full_name); ?></td>
                                <td><?php echo e($customer->email ?? '—'); ?></td>
                                <td><?php echo e($customer->phone ?? '—'); ?></td>
                                <td><?php echo e($customer->company_name ?? '—'); ?></td>
                                <td>
                                    <span class="badge class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                        'text-bg-secondary' => $customer->status === 'prospect',
                                        'text-bg-success' => $customer->status === 'actif',
                                        'text-bg-warning' => $customer->status === 'inactif',
                                        'text-bg-danger' => $customer->status === 'perdu',
                                    ]); ?>"">
                                        <?php echo e(ucfirst($customer->status)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($customer->user->name ?? '—'); ?></td>
                                <td class="text-end">
                                    <div class="btn-group btn-group-sm">
                                        <a href="#" class="btn btn-light"><i class="bi bi-eye"></i></a>
                                        <a href="#" class="btn btn-light"><i class="bi bi-pencil"></i></a>
                                        <button type="button" class="btn btn-light"><i class="bi bi-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">
                                    <i class="bi bi-emoji-frown me-1"></i>Aucun client trouvé.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        
        <?php if($customers->hasPages()): ?>
            <div class="card-footer bg-white">
                <div class="d-flex justify-content-center">
                    <?php echo e($customers->links()); ?>

                </div>
            </div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\rmoryson\Herd\infotools\resources\views/consumer/index.blade.php ENDPATH**/ ?>