<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>InfoTools</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" defer></script>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/choices.js/public/assets/styles/choices.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/choices.js/public/assets/scripts/choices.min.js" defer></script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>


<div class="app">


    <div class="navbar">
        <div class="navbar_title text-white ">
            <img style="width: 200px;" src="<?php echo e(asset('img/logo.png')); ?>" alt="InfoTools Logo">
        </div>

        <div class="navbar_link">
            <ul class="nav flex-column text-center">

                <li class="nav-item">
                    <a href="<?php echo e(url('/')); ?>"
                        class="nav-link d-flex align-items-center <?php echo e(request()->is('/') ? 'active' : ''); ?>">
                        <i class="bi bi-speedometer2 me-2"></i>
                        <span>Tableau de bord</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('customer.index')); ?>"
                        class="nav-link d-flex align-items-center <?php echo e(request()->is('clients*') ? 'active' : ''); ?>">
                        <i class="bi bi-people me-2"></i>
                        <span>Clients</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('appointments.index')); ?>"
                        class="nav-link d-flex align-items-center <?php echo e(request()->is('appointments*') ? 'active' : ''); ?>">
                        <i class="bi bi-calendar-check me-2"></i>
                        <span>Rendez-vous</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('products.index')); ?>"
                        class="nav-link d-flex align-items-center <?php echo e(request()->is('products*') ? 'active' : ''); ?>">
                        <i class="bi bi-box-seam me-2"></i>
                        <span>Produits</span>
                    </a>
                </li>



                <li class="nav-item">
                    <a href="<?php echo e(route('invoices.index')); ?>"
                        class="nav-link d-flex align-items-center <?php echo e(request()->is('invoices*') ? 'active' : ''); ?>">
                        <i class="bi bi-receipt me-2"></i>
                        <span>Facturation</span>
                    </a>
                </li>
            </ul>

        </div>
    </div>

    <div class="content m-3">
        <?php if (! empty(trim($__env->yieldContent('header')))): ?>
            <div class="dashboard-header m-3">
                <h1><?php echo $__env->yieldContent("title"); ?></h1>

                <div class="header-right">
                    <!-- Search -->
                    <form role="search">
                        <div class="input-group">
                            <span class="input-group-text">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-search"
                                    viewBox="0 0 16 16">
                                    <path
                                        d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001l3.85 3.85a1 1 0 0 0 1.415-1.415l-3.85-3.85zm-5.242 0a5 5 0 1 1 0-10 5 5 0 0 1 0 10z" />
                                </svg>
                            </span>
                            <input type="text" class="form-control" placeholder="Rechercher..." />
                        </div>
                    </form>

                    <!-- Bell -->
                    <button class="icon-btn position-relative" title="Notifications">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-bell" viewBox="0 0 16 16">
                            <path
                                d="M8 16a2 2 0 0 0 1.985-1.75H6.015A2 2 0 0 0 8 16zm.104-14.1a1 1 0 0 0-.208 0C7.042 1.01 6 2.2 6 4c0 1.098-.356 2.03-.99 2.682C4.33 7.565 4 8.257 4 9v1l-.854 1.708A1 1 0 0 0 4 13h8a1 1 0 0 0 .854-1.292L12 10V9c0-.743-.33-1.435-1.01-1.318C10.356 6.03 10 5.098 10 4c0-1.8-1.042-2.99-1.896-2.1z" />
                        </svg>
                        <span class="badge">3</span>
                    </button>

                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show mt-3 d-flex align-items-center" role="alert">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                    class="bi bi-check-circle-fill me-2" viewBox="0 0 16 16">
                    <path
                        d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08-1.04L7.477 9.417 5.384 7.323a.75.75 0 1 0-1.06 1.06l2.5 2.5a.75.75 0 0 0 1.06 0l4.5-4.5z" />
                </svg>
                <div>
                    <?php echo e(session('success')); ?>

                </div>
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Fermer"></button>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html><?php /**PATH C:\Users\rmoryson\Herd\infotools\resources\views/layout/app.blade.php ENDPATH**/ ?>