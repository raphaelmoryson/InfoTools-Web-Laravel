

<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-3">

        
        <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap">
            <h1 class="h3 mb-0">
                <i class="bi bi-people me-2"></i>Clients
            </h1>
            <a href="<?php echo e(route('customer.create')); ?>" class="btn btn-primary">
                <i class="bi bi-person-plus me-2"></i>Ajouter un client
            </a>
        </div>

        
        <div class="card mb-3">
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('customer.index')); ?>" class="row g-2 align-items-center">
                    <div class="col-md-8">
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-search"></i></span>
                            <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control"
                                placeholder="Rechercher un client, une société, un email...">
                        </div>
                    </div>
                    <div class="col-md-4 text-end">
                        <button type="submit" class="btn btn-outline-secondary w-100 w-md-auto">
                            Rechercher
                        </button>
                    </div>
                </form>
            </div>
        </div>

        
        <div class="card">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table align-middle mb-0 table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Nom</th>
                                <th>Email</th>
                                <th>Téléphone</th>
                                <th>Société</th>
                                <th>Statut</th>
                                <th>Commercial</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($customer->id); ?></td>
                                    <td>
                                        
                                        <a href="<?php echo e(route('customer.show', $customer->id)); ?>" class="text-decoration-none fw-bold text-dark">
                                            <?php echo e($customer->full_name); ?>

                                        </a>
                                    </td>
                                    <td><?php echo e($customer->email ?? '—'); ?></td>
                                    <td><?php echo e($customer->phone ?? '—'); ?></td>
                                    <td><?php echo e($customer->company_name ?? '—'); ?></td>
                                    <td>
                                        <span class="badge class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                            'text-bg-secondary' => $customer->status === 'prospect',
                                            'text-bg-success' => $customer->status === 'actif',
                                            'text-bg-warning' => $customer->status === 'inactif',
                                            'text-bg-danger' => $customer->status === 'perdu',
                                        ]); ?>"">
                                            <?php echo e(ucfirst($customer->status)); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($customer->user->name ?? '—'); ?></td>
                                    <td class="text-end">
                                        <div class="btn-group btn-group-sm">
                                            
                                            <a href="<?php echo e(route('customer.show', $customer->id)); ?>" class="btn btn-light" title="Voir les achats">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('customer.edit', $customer->id)); ?>" class="btn btn-light">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <button type="button" class="btn btn-light text-danger" data-bs-toggle="modal"
                                                data-bs-target="#deleteModal" data-id="<?php echo e($customer->id); ?>"
                                                data-name="<?php echo e($customer->full_name); ?>">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center py-4 text-muted">
                                        <i class="bi bi-emoji-frown me-1"></i>Aucun client trouvé.
                                    </td>
                                </tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($customers->hasPages()): ?>
                <div class="card-footer bg-white">
                    <div class="d-flex justify-content-center">
                        <?php echo e($customers->links()); ?>

                    </div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

    </div>

    
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" id="deleteForm">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <div class="modal-content">
                    <div class="modal-header bg-danger text-white">
                        <h5 class="modal-title" id="deleteModalLabel"><i
                                class="bi bi-exclamation-triangle me-2"></i>Confirmer la suppression</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Souhaitez-vous vraiment supprimer le client <strong id="customerName"></strong> ?</p>
                        <p class="text-muted small mb-0">Cette action est irréversible.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-danger">Supprimer</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const deleteModal = document.getElementById('deleteModal');
            deleteModal.addEventListener('show.bs.modal', event => {
                const button = event.relatedTarget;
                const id = button.getAttribute('data-id');
                const name = button.getAttribute('data-name');

                const form = deleteModal.querySelector('#deleteForm');
                const nameHolder = deleteModal.querySelector('#customerName');

                form.action = `/clients/${id}`;
                nameHolder.textContent = name || 'ce client';
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\rmoryson\Herd\infotools\resources\views/customer/index.blade.php ENDPATH**/ ?>