

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-4">
    <h1 class="h4 mb-3">
        <i class="bi bi-eye me-2"></i>Rendez-vous
    </h1>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="card">
        <div class="card-body row g-3">
            
            <div class="col-md-6">
                <label class="form-label fw-bold">Client</label>
                <div><?php echo e($appointment->customer->name ?? '-'); ?></div>
            </div>

            
            <div class="col-md-6">
                <label class="form-label fw-bold">Commercial</label>
                <div><?php echo e($appointment->commercial->name ?? '-'); ?></div>
            </div>

            
            <div class="col-md-6">
                <label class="form-label fw-bold">Début</label>
                <div><?php echo e($appointment->start_at?->format('d/m/Y H:i') ?? '-'); ?></div>
            </div>

            
            <div class="col-md-6">
                <label class="form-label fw-bold">Fin</label>
                <div><?php echo e($appointment->end_at?->format('d/m/Y H:i') ?? '-'); ?></div>
            </div>

            
            <div class="col-12">
                <label class="form-label fw-bold">Objet</label>
                <div><?php echo e($appointment->subject); ?></div>
            </div>

            
            <div class="col-12">
                <label class="form-label fw-bold">Notes</label>
                <div style="white-space: pre-wrap;"><?php echo e($appointment->notes ?? '-'); ?></div>
            </div>

            
            <div class="col-12 d-flex justify-content-between mt-2">
                <a href="<?php echo e(route('appointments.index')); ?>" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-2"></i>Retour
                </a>
                <div class="d-flex gap-2">
                    <a href="<?php echo e(route('appointments.edit', $appointment)); ?>" class="btn btn-primary">
                        <i class="bi bi-pencil-square me-2"></i>Modifier
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\rmoryson\Herd\infotools\resources\views/appointments/show.blade.php ENDPATH**/ ?>