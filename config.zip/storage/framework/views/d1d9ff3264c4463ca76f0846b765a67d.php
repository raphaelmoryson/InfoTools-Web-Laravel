<?php $__env->startSection('title', 'Factures'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-4">

        <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap">
            <a href="<?php echo e(route('invoices.create')); ?>" class="btn btn-primary">
                <i class="bi bi-plus-circle me-2"></i>Nouvelle facture
            </a>
        </div>

        <div class="card mb-3">
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('invoices.index')); ?>" class="row g-2">
                    <div class="col-md-4">
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-search"></i></span>
                            <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control"
                                placeholder="Référence ou client...">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <input type="date" name="from" value="<?php echo e(request('from')); ?>" class="form-control" placeholder="Du">
                    </div>
                    <div class="col-md-3">
                        <input type="date" name="to" value="<?php echo e(request('to')); ?>" class="form-control" placeholder="Au">
                    </div>
                    <div class="col-md-2 d-grid">
                        <button class="btn btn-outline-secondary"><i class="bi bi-sliders me-2"></i>Filtrer</button>
                    </div>
                </form>
            </div>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="card shadow-sm border-0">
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Date</th>
                            <th>Référence</th>
                            <th>Client</th>
                            <th class="text-end">Total</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(\Carbon\Carbon::parse($inv->invoiced_at)->format('d/m/Y')); ?></td>
                                <td class="fw-semibold"><?php echo e($inv->reference); ?></td>
                                <td><?php echo e($inv->customer->name ?? '—'); ?></td>
                                <td class="text-end"><?php echo e(number_format($inv->total, 2, ',', ' ')); ?> €</td>
                                <td class="text-end">
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo e(route('invoices.show', $inv)); ?>" class="btn btn-light" title="Voir"><i
                                                class="bi bi-eye"></i></a>
                                        <a href="<?php echo e(route('invoices.edit', $inv)); ?>" class="btn btn-light" title="Éditer"><i
                                                class="bi bi-pencil"></i></a>
                                        <form action="<?php echo e(route('invoices.destroy', $inv)); ?>" method="POST"
                                            onsubmit="return confirm('Supprimer cette facture ?')" class="d-inline">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-light" title="Supprimer"><i class="bi bi-trash"></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted py-4">Aucune facture.</td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($invoices->hasPages()): ?>
                <div class="card-footer bg-white py-2">
                    <div class="d-flex justify-content-center">
                        <?php echo e($invoices->links()); ?>

                    </div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        </div>
    </div>

    <?php $__env->startPush('styles'); ?>
        <style>
            .pagination .page-link {
                padding: .25rem .5rem;
                font-size: .875rem
            }

            .pagination {
                gap: .25rem
            }
        </style>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\rmoryson\Herd\infotools\resources\views/invoices/index.blade.php ENDPATH**/ ?>